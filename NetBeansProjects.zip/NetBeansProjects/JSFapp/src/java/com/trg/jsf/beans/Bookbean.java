package com.trg.jsf.beans;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;

/**
 *
 * @author oracle
 */
@Named(value = "book")
@RequestScoped
public class Bookbean {

    /**
     * Creates a new instance of Bookbean
     */
    
    static Map<Integer,Book> books = new HashMap<Integer,Book>();
    
    static{
        books.put(1, new Book(1,"xyz",2));
        books.put(2, new Book(2,"pranay biography",2));
        books.put(3, new Book(3,"cricket",2));
    }
    
    Book newBook = new Book();
    String result = "";
    List<Book> listBook = new ArrayList<>();

    public List<Book>getListBook() {
        return listBook;
    }

    public void setListBook(List<Book>listBook) {
        this.listBook = listBook;
    }
    

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
    
    public Bookbean() {
        
    }

    public Book getNewBook() {
        return newBook;
    }

    public void setNewBook(Book newBook) {
        this.newBook = newBook;
    }
    
    public String getBook(){
        newBook = books.get(this.newBook.bookId);
        result="book retrived";
        return null;
    }
    
    public String createBook(){
        books.put(this.newBook.bookId, newBook);
        result="book ceated";
        newBook=null;
        return null;
    }
    
    public String deleteBook(){
        books.remove(this.newBook.getBookId());
        result="book retrived";
        newBook = null;
        return null;
    }
    public String getAllBooks(){
        this.listBook = new ArrayList<>();
        for(Book b : books.values())this.listBook.add(b);
        result  = "all books returned";
        return null;
    }
    
}
