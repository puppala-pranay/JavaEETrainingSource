/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trg.jsf.beans;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

/**
 *
 * @author oracle
 */
@Named(value = "calc")
@RequestScoped
public class Calculator {

   
    
    private Integer number1;
    private Integer number2;
    private Integer sum;
    private String result="";

    public Integer getNumber1() {
        return number1;
    }

    public void setNumber1(Integer number1) {
        this.number1 = number1;
    }

    public Integer getNumber2() {
        return number2;
    }

    public void setNumber2(Integer number2) {
        this.number2 = number2;
    }

    public Integer getSum() {
        return sum;
    }

    public void setSum(Integer sum) {
        this.sum = sum;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
    
    
    
    public Calculator() {
    }

   
    
    public String add(){
        sum = number1+number2;
        result = "Sum is "+sum;
        return "calculator";
    }
    
    public String subtract(){
        result = "difference is "+(number1-number2);
        return "calculator";
    }
    
}
