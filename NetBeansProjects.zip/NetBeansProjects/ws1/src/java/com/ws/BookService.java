/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ws;

import com.ws1.things.Book;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;

/**
 *
 * @author oracle
 */
@WebService(serviceName = "BookService")
public class BookService {

    /**
     * This is a sample web service operation
     */
    
    static Map<Integer,Book> books = new HashMap<Integer,Book>();
    
    static{
        books.put(1, new Book(1,"xyz",2));
        books.put(2, new Book(2,"pranay biography",2));
        books.put(3, new Book(3,"cricket",2));
    }
    
    @WebMethod(operationName = "getBook")
    public @WebResult(name="book")Book getBook(@WebParam(name = "bookId")int id){
        return books.get(id);
    }
    
    @WebMethod(operationName = "saveBook")
    public void saveBook(@WebParam(name = "newBook")Book b)throws DuplicateBookException{
        if(books.containsKey(b.getBookId()))throw new DuplicateBookException(b.getBookId());
        books.put(b.getBookId(), b);
    }
    
    @WebMethod(operationName = "getAllBooks")
    public @WebResult(name = "bookList")List<Book> getAllBooks(){
        List<Book> li = new ArrayList();
        books.values().stream().forEach((b) -> {
            li.add(b);
        });
        
        return li;
    }
    
    
   
    
}
