/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ws;

/**
 *
 * @author oracle
 */
public class DuplicateBookException extends Exception {

    private int id;
    
    public DuplicateBookException(int id){
        this.id = id;
    }
    
    @Override
    public String getMessage(){
        return "the book with id "+ this.id+" already exists";
    }
    
}
