/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ws;

import javax.jws.*;

/**
 *
 * @author oracle
 */
@WebService(serviceName = "Calculatorservice")
public class Calculatorservice {

    @WebMethod(operationName = "addNumbers")
    public @WebResult(name = "sum") int add(@WebParam(name = "firstNumber")int x, @WebParam(name = "secondNumber")int y) {
        return x+y;
    }
}
