/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rest.services;

import com.rest.beans.AppResponse;
import com.rest.beans.Book;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * REST Web Service
 *
 * @author oracle
 */
@Path("books")
public class Bookresource {

  
    
    static Map<Integer,Book> books = new HashMap<>();
    static{
        books.put(111, new Book(111,"xyz",2));
        books.put(222, new Book(222,"pranay biography",2));
        books.put(333, new Book(333,"cricket",2));
    }
    
    
    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
    public Response getBook( @PathParam("id") int bookId) {
        
        Book b =  books.get(bookId);
        
        if(b!=null)return Response.status(Response.Status.OK).entity(b).build();
        else {
             return Response.status(Response.Status.NOT_FOUND).entity(
                     new AppResponse("Book with Id "+bookId+ " not found")).build();
        }
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.TEXT_PLAIN)
    public String saveBook(Book b){
        if(books.containsKey(b.getBookId()))return "Book with the id "+ b.getBookId()+" already exists";
        books.put(b.getBookId(),b);
        return "Book saved successfully";
        
    }
    
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.TEXT_PLAIN)
    public String updateBook(Book b){
        if(books.containsKey(b.getBookId()))books.replace(b.getBookId(), b);
        else books.put(b.getBookId(),b);
        return "Book uodated successfully";
        
    }
    
    @PATCH
    @Path("{id}/{quant}")
    @Produces({MediaType.APPLICATION_JSON})
    public Response updateQuantity( @PathParam("id") int bookId,@PathParam("quant") int quant) {
        
        Book b =  books.get(bookId);
        b.setQuantity(quant);
        
        books.put(b.getBookId(), b);
        return Response.status(Response.Status.OK).entity(b).build();
         
                
    }
    
    @GET
    public Collection<Book> getAll(){
    
        return books.values();
    }
    

    @DELETE
    @Path("{id}")
    @Produces({MediaType.APPLICATION_JSON,MediaType.TEXT_PLAIN})
    public String deleteBook(@PathParam("id") int bookId){
        if(!books.containsKey(bookId))return "Book with id "+bookId+" not exists";
        books.remove(bookId);
        return "book with id "+bookId+" removed successfully";
    }
   
}
