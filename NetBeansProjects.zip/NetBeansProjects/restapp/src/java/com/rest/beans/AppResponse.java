/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.rest.beans;

/**
 *
 * @author oracle
 */
public class AppResponse {
    private String msg;

    public AppResponse(String msg) {
        this.msg = msg;
    }

    public AppResponse() {
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
    
    
    
}
