/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejbclientapplication;

import com.trg.beans.ShoppingBeanRemote;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Properties;
import javax.jms.*;
import javax.jms.QueueConnectionFactory;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 *
 * @author oracle
 */
public class jmsMain {
    public static void main(String[] args) throws NamingException, JMSException {
        Properties p = new Properties();
        p.put(Context.INITIAL_CONTEXT_FACTORY,"weblogic.jndi.WLInitialContextFactory");
        p.put(Context.PROVIDER_URL, "t3://127.0.0.1:7001");
        Context ctx = new InitialContext(p);  ///used for jndi search
        //CalculatorBeanRemote ref = (CalculatorBeanRemote) ctx.lookup("calc#com.trg.beans.CalculatorBeanRemote");
        QueueConnectionFactory factory = (QueueConnectionFactory) ctx.lookup("jndi/myfactory");
        Queue queue = (Queue) ctx.lookup("jndi/myqueue");
        System.out.println("Queue located");
        
        
        QueueConnection con = factory.createQueueConnection();
        //QueueSession session = con.createQueueSession(true, 0);
        Session session = con.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
        MessageProducer producer = session.createProducer(queue);
        TextMessage message = session.createTextMessage("Message from the client "+LocalDate.now());
        producer.send(message);
        System.out.println("Message sent to the queue");
        session.close();
        
    }
    
}
