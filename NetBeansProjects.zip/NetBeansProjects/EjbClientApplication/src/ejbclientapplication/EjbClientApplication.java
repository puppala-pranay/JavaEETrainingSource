/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejbclientapplication;

import com.trg.beans.CalculatorBeanRemote;
import com.trg.beans.StockBeanRemote;
import java.util.Properties;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 *
 * @author oracle
 */
public class EjbClientApplication {

    
    public static void main(String[] args) throws NamingException {
        // TODO code application logic here
        
        Properties p = new Properties();
        p.put(Context.INITIAL_CONTEXT_FACTORY,"weblogic.jndi.WLInitialContextFactory");
        p.put(Context.PROVIDER_URL, "t3://127.0.0.1:7001");
        Context ctx = new InitialContext(p);  ///used for jndi search
        //CalculatorBeanRemote ref = (CalculatorBeanRemote) ctx.lookup("calc#com.trg.beans.CalculatorBeanRemote");
        StockBeanRemote ref2 = (StockBeanRemote) ctx.lookup("stocks#com.trg.beans.StockBeanRemote");
        ref2.putStock("ggl", 231.9);
        Double res = ref2.getPrice("ggl");
        System.out.println(res);
        
    }
    
}
