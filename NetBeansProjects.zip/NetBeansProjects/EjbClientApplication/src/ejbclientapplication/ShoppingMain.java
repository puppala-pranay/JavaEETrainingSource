/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejbclientapplication;

import com.trg.beans.ItemExistsException;
import com.trg.beans.ShoppingBeanRemote;
import com.trg.beans.StockBeanRemote;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 *
 * @author oracle
 */
public class ShoppingMain {
    public static void main(String[] args) throws NamingException {
        // TODO code application logic here
        
        Properties p = new Properties();
        p.put(Context.INITIAL_CONTEXT_FACTORY,"weblogic.jndi.WLInitialContextFactory");
        p.put(Context.PROVIDER_URL, "t3://127.0.0.1:7001");
        Context ctx = new InitialContext(p);  ///used for jndi search
        //CalculatorBeanRemote ref = (CalculatorBeanRemote) ctx.lookup("calc#com.trg.beans.CalculatorBeanRemote");
        ShoppingBeanRemote ref = (ShoppingBeanRemote) ctx.lookup("shop#com.trg.beans.ShoppingBeanRemote");
        try {
            ref.addItem("laptop");
            ref.addItem("book");
            ref.addItem("book");
        } catch (ItemExistsException ex) {
            System.out.println(ex.getMessage());
        }
        System.out.println(ref.getItems());
        ref.checkout();
        ref.deleteItem("laptop");
        System.out.println(ref.getItems());
        
        
        
    }
}
