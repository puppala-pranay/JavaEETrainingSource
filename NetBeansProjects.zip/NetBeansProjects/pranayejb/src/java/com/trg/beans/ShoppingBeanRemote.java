/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trg.beans;

import java.util.List;
import javax.ejb.Remote;

@Remote
public interface ShoppingBeanRemote {
    
   void addItem(String item) throws ItemExistsException;
   void deleteItem(String item);
   List<String> getItems();
       void checkout();

    
}
