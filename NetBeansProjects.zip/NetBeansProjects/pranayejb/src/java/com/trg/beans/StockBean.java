/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trg.beans;

import java.util.HashMap;
import java.util.Map;
import javax.ejb.Stateless;

/**
 *
 * @author oracle
 */
@Stateless(mappedName = "stocks")

public class StockBean implements StockBeanRemote {
    
    Map<String,Double> stockMap;
    
    public StockBean(){
        stockMap = new HashMap<>();
    }

    @Override
    public void putStock(String symbol, Double price) {
        if(stockMap.containsKey(symbol)){
               System.out.println("Cant add "+symbol+" -> already contains ");
        }
        else stockMap.put(symbol, price);
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    @Override
    public Double getPrice(String symbol) {
        if(stockMap.containsKey(symbol))return stockMap.get(symbol);
        return null;
    }
    
    
}
