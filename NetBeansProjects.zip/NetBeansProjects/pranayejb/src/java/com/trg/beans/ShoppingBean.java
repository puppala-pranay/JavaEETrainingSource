/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trg.beans;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.Remove;
import javax.ejb.Stateful;

/**
 *
 * @author oracle
 */
@Stateful(mappedName = "shop")
public class ShoppingBean implements ShoppingBeanRemote {

    
    List<String> items = new ArrayList<String> ();;
    
   
    
    
    @Override
    public void addItem(String item) throws ItemExistsException {
        if(items.contains(item)){
            throw new ItemExistsException(item);
        }
        items.add(item);
    }

    @Override
    public void deleteItem(String item) {
        items.remove(item);
    }

    @Override
    public List<String> getItems() {
        return this.items;
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    @Override
    @Remove
    public void checkout() {
        this.items = null;
    }
}
