package com.stocks.helpers;

import com.stocks.entities.Stocks;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author oracle
 */

@Named("processor")
@RequestScoped
public class StockDataProcessor {
    
        @PersistenceContext
        EntityManager em;
        @Resource
        UserTransaction utx;
                
        public String getStockDetails(HttpServletRequest request, HttpServletResponse response){
            String sym = request.getParameter("symbol");
            Stocks stock = em.find(Stocks.class, sym);
            if(stock==null){
                request.setAttribute("message", "Stock with symbol "+sym+" not found");
                return "response";
            }else{
                request.setAttribute("stk", stock);
                return "stockdetails";
            }
            
        }
        
        public String getStockList(HttpServletRequest request, HttpServletResponse response){
            Query q = em.createNamedQuery("Stocks.findAll");
            List<Stocks> list =  q.getResultList();
            request.setAttribute("stockslist", list);
            return "stocklist";
        }
        

    public String saveStock(HttpServletRequest request, HttpServletResponse response)  {
           
        String sym = request.getParameter("symbol");
        Stocks stock = em.find(Stocks.class, sym);
        
        if(stock!=null){
            request.setAttribute("message", "Stock with symbol "+sym+" already exists");
            
        }
        else{
            String name = request.getParameter("name");
            double price  = Double.parseDouble(request.getParameter("price"));
            try {
                utx.begin();
                stock = new Stocks(sym,name,price);
                em.persist(stock);
                utx.commit();
            } catch (NotSupportedException ex) {
                Logger.getLogger(StockDataProcessor.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SystemException ex) {
                Logger.getLogger(StockDataProcessor.class.getName()).log(Level.SEVERE, null, ex);
            } catch (RollbackException ex) {
                Logger.getLogger(StockDataProcessor.class.getName()).log(Level.SEVERE, null, ex);
            } catch (HeuristicMixedException ex) {
                Logger.getLogger(StockDataProcessor.class.getName()).log(Level.SEVERE, null, ex);
            } catch (HeuristicRollbackException ex) {
                Logger.getLogger(StockDataProcessor.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SecurityException ex) {
                Logger.getLogger(StockDataProcessor.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IllegalStateException ex) {
                Logger.getLogger(StockDataProcessor.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            
            request.setAttribute("message", "Stock with symbol "+sym+" is created");
        }
        
        
        return "response";
        
        
    }

        
        
    
    
}
