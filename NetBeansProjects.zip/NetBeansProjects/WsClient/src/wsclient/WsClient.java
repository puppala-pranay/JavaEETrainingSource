/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wsclient;

import com.client.Calculatorservice;
import com.client.Calculatorservice_Service;
import java.util.logging.Level;
import java.util.logging.Logger;
import wsclient.Book;

/**
 *
 * @author oracle
 */
public class WsClient {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        Calculatorservice_Service cs = new Calculatorservice_Service();
//        Calculatorservice ser = cs.getCalculatorservicePort();
//        
//        int sum = ser.addNumbers(234, 122);
//        System.out.println("sum = "+sum );

        BookService_Service bs = new BookService_Service();
        BookService bservice = bs.getBookServicePort();
        
        System.out.println(bservice.getBook(1));
        try {
            bservice.saveBook(new Book(5,3,"nothing"));
        } catch (DuplicateBookException_Exception ex) {
            System.out.println(ex.getMessage());
        }
        System.out.println(bservice.getAllBooks());
        
        
    }
    
}
