
package jpa1;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JpaMain {

 
    public static void main(String[] args) {
        // TODO code application logic here
        
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa1PU");
        EntityManager em = emf.createEntityManager();
        
        Product p1 = em.find(Product.class, 200);
        System.out.println(p1);
        
        em.getTransaction().begin();
//        Product p2 = new Product(300, "UPS", 3200.0);
//        em.persist(p2);
        
//        p1.setPrice(62000.0);
//        em.merge(p1);

        em.remove(p1);
        
        em.getTransaction().commit();
        em.close();
    }
    
}
