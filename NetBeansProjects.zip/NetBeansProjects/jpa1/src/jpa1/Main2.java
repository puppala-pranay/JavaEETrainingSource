/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jpa1;

import com.trg.entity.Employee;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author oracle
 */
public class Main2 {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa1PU");
        EntityManager em = emf.createEntityManager();
        
        em.getTransaction().begin();
//        
//        
//        Product p1,p2,p3;
//        p1 = new Product("chair", 1200.0);
//        p2 = new Product("table", 2300.0);
//        p3 = new Product("Double Cot", 5500.0);
//        System.out.println(p1+"\n"+p2+"\n"+p3);
//        em.persist(p1);
//        em.persist(p2);
//        em.persist(p3);
             

        Employee e1 = new Employee("donkey",100000.0);
        Employee e2 = new Employee("monkey",200000.0);
        Employee e3 = new Employee("piggy",300000.0);
        
        em.persist(e1);
        em.persist(e2);
        em.persist(e3);
        
        
        em.getTransaction().commit();
        System.out.println("Added employees");
        em.close();
    }
}
