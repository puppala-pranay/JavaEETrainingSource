/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jpa1;

import com.trg.entity.Employee;
import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

/**
 *
 * @author oracle
 */
public class jpqlDemo {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa1PU");
        EntityManager em = emf.createEntityManager();
        
        
//        Query q = em.createQuery("select e.name from Employee e  where e.salary between :salLower and :salHigher" );
//        Scanner sc = new Scanner(System.in);
//        System.out.println("Enter lower salary");
//        q.setParameter("salLower", sc.nextDouble());
//        System.out.println("Enter upper salary");
//        q.setParameter("salHigher", sc.nextDouble());
//        List<String> list = q.getResultList();

//        Query q =   em.createNamedQuery("Employee.findAll") ;
//        Query q2 = em.createNamedQuery("Employee.findByName");
//        q2.setParameter("name", "%P%");
//        Query q3 = em.createNamedQuery("Employee.findBySal");
//        q3.setParameter("sal", 200001);
//        List<Employee> list = q2.getResultList();
//        for(Employee e : list){
//            System.out.println(e);
//        }
        
        Query q = em.createQuery("select e.name,e.salary from Employee e" );
        List<Object[]> list = q.getResultList();
        for(Object[] e : list){
            System.out.println("salary of "+e[0]+" is "+e[1]);
        }
        
        em.close();
    }
}
