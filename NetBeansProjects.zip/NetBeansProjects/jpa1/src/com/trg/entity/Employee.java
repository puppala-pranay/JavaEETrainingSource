/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trg.entity;

import java.io.Serializable;
import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author oracle
 */

@Entity
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Employee.findAll", query = "SELECT p FROM Employee p"),
    @NamedQuery(name = "Employee.findBySal", query = "SELECT p FROM Employee p WHERE p.salary > :sal"),
    @NamedQuery(name = "Employee.findByName", query = "SELECT p FROM Employee p WHERE p.name like :name")
    })
public class Employee implements Serializable {
    
    @Id
    @GeneratedValue(strategy =  GenerationType.SEQUENCE,generator = "abcd")
    @SequenceGenerator(name = "abcd",sequenceName = "empseq",initialValue = 100)
    
    private int empid;
    
    @Column(length = 20)
    private String name;
    private double salary;

    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    public Employee() {
    }

    public int getEmpid() {
        return empid;
    }

    public void setEmpid(int empid) {
        this.empid = empid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Employee{" + "empid=" + empid + ", name=" + name + ", salary=" + salary + '}';
    }
    
    
}
