package com.trg.beans;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author oracle
 */
public class ItemExistsException  extends Exception{
    private String item;

    public ItemExistsException(String item) {
        this.item = item;
    }
    
    public String getMessage(){
        return "Item "+this.item+" Also Exists";
    }
}
